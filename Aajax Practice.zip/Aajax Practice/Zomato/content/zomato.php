<?php include "../includes/header.php"; ?>
<body>

	<table class="table table-striped ">

  <thead>
    <h1 class="text-center">Zomto</h1>
    <tr>
      <th scope="col">APP</th>
      <th scope="col">ORDER ID </th>
      <th scope="col">ORDER DATE</th>
      <th scope="col">ORDER TIME</th>
      <th scope="col">STATUS</th>
      <th scope="col">AMOUNT</th>
      <th scope="col">ITEMS DETAILS</th>
      <th scope="col">ACTION</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">Zomato</th>
      <td>1458925599</td>
      <td>2020-02-03</td>
      <td>New Order</td>
      <td>Rs.125.66</td>
      <td><a href="#">View</a></td>
      <td></td>
      <td><button type="submit" class="btn btn-default " style=" font-weight: bold; padding: 4px;">Picked Up</button></td>
    </tr>
     <tr>
      <th scope="row">Zomato</th>
      <td>1458925599</td>
      <td>2020-02-03</td>
      <td>New Order</td>
      <td>Rs.125.66</td>
      <td><a href="#">View</a></td>
      <td></td>
      <td><button type="submit" class="btn btn-default " style=" font-weight: bold; padding: 4px;">Picked Up</button></td>
    </tr>
     <tr>
      <th scope="row">Zomato</th>
      <td>1458925599</td>
      <td>2020-02-03</td>
      <td>New Order</td>
      <td>Rs.125.66</td>
      <td><a href="#">View</a></td>
      <td></td>
      <td><button type="submit" class="btn btn-default " style=" font-weight: bold; padding: 4px;">Picked Up</button></td>
    </tr>
     <tr>
      <th scope="row">Zomato</th>
      <td>1458925599</td>
      <td>2020-02-03</td>
      <td>New Order</td>
      <td>Rs.125.66</td>
      <td><a href="#">View</a></td>
      <td></td>
      <td><button type="submit" class="btn btn-default " style=" font-weight: bold; padding: 4px;">Picked Up</button></td>
    </tr>
     <tr>
      <th scope="row">Zomato</th>
      <td>1458925599</td>
      <td>2020-02-03</td>
      <td>New Order</td>
      <td>Rs.125.66</td>
      <td><a href="#">View</a></td>
      <td></td>
      <td><button type="submit" class="btn btn-default " style=" font-weight: bold; padding: 4px;">Picked Up</button></td>
    </tr>
   
  </tbody>
</table>






<?php include "../includes/footer.php"; ?>
</body>
</html>