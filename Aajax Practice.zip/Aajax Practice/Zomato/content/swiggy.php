<?php include "../includes/header.php"; ?>

<!-- Default form contact -->
<div class="container">
<form class="text-center border border-light p-5" action="#!">

    <p class="h4 mb-4">Swiggy</p>

    
  <div class="row">
    
    	<div class="col">
	      
	      	<input type="text" class="form-control" placeholder="First name">
		</div>
	    

	    
	 	<div class="col">
	      
	     	<input type="text" class="form-control" placeholder="Last name">
	    </div>
	    
  </div><br>

    
    <input type="number" id="defaultContactFormEmail" class="form-control mb-4" placeholder="Number">

   

    
    <div class="form-group">
        <input type="email" name="email" class="form-control">
    </div>

    

    
    <button class="btn btn-info btn-block" type="submit">Send</button>

</form>
<!-- Default form contact -->
</div>


  




<?php include "../includes/footer.php"; ?>