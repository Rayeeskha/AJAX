<?php include "includes/header.php"; ?>
<body>
	<div class="container">

	
	<ul id="nav">
		<li>
			<a href="zomato">
				<img src="img/zomato.jpeg" id="button"  style="height: 100px; width: 220px; border-bottom: 2px solid black;  " class="rounded float-left img-thumbnail img-responsive" alt="..." >	
			</a>
		</li>
		<li>
			<a href="swiggy">
				<img src="img/swiggy.jpg" id="swiggy" style="height: 100px; width: 220px; border-bottom: 2px solid black;" class="rounded float-right img-thumbnail img-responsive" alt="...">
			</a>
		</li>
		<div style="height: 200px;"></div>
	</ul>



	<div id="content"></div>











<?php include "includes/footer.php"; ?>
</html>
<script type="text/javascript" src="js/custom.js"></script>