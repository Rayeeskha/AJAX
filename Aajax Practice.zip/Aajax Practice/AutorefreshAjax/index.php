<?php include "includes/header.php"; ?>

<ul id="nav">
	<li><a href="index">Home</a></li>
	<li><a href="about">About us</a></li>
	<li><a href="content">Contact</a></li>
</ul>
<div id="content">
	
</div>



<?php include "includes/footer.php"; ?>
<script type="text/javascript" src="js/script.js"></script>